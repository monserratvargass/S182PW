@extends('layouts.plantilla')
    
@section('titulo','Inicio') //se abre y se cierra
    

@section('contenido')

<h1 class="display-1 text-center text-danger mt-5">Home</h1>

@endsection