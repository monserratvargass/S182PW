 

<?php $__env->startSection('titulo','Formulario'); ?>

<?php $__env->startSection('contenido'); ?>

<h1 class="display-1 text-center text-danger mt-5">Formulario</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\S182PW\practica3\resources\views/formulario.blade.php ENDPATH**/ ?>