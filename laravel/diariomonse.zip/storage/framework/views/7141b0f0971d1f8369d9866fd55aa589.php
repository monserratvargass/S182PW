 

<?php $__env->startSection('titulo','Recuerdos'); ?>

<?php $__env->startSection('contenido'); ?>

<h1 class="display-1 text-center text-danger mt-5">Recuerdos</h1>

<?php if(session()->has('confirmacion')): ?>

<div class="alert alert-success alert-dismissible fade show" role="alert">
  <strong> <?php echo e(session('confirmacion')); ?> </strong> <!-- mandar llamar un echo -->
  <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>

<?php endif; ?>

<?php echo $__env->make('partials.pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__currentLoopData = $consulRecuerdos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="card w-75 mb-3 mt-5">
    <div class="card-body">
      <h5 class="card-title fw-semibold"><?php echo e($item->titulo); ?></h5>
      <p class="card-text fst-italic"><?php echo e($item->fecha); ?></p>
      <p class="card-text fst-italic"><?php echo e($item->recuerdo); ?></p>
      <!-- Button trigger modal -->
<button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar<?php echo e($item->id); ?>">
  Editar
</button>
<button href="#" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#eliminarRecuerdoModal<?php echo e($item->id); ?>">Eliminar</button>
    </div>
  </div>
<?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\S182PW\laravel\resources\views/recuerdos.blade.php ENDPATH**/ ?>