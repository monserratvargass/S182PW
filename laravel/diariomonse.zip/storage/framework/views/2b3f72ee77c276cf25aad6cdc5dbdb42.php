    
<?php $__env->startSection('titulo','Inicio'); ?> //se abre y se cierra
    

<?php $__env->startSection('contenido'); ?>

<h1 class="display-1 text-center text-danger mt-5">Home</h1>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\S182PW\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>